# Иерархия пакета N7

Начинайте с START-HERE.md. Родительская ссылка на дочерний документ не считается включением его содержания. Сохранены только самостоятельные требования и уточнения; дублирующие или исторические нижние документы исключены.

1. PRD → исходная Specification, алгоритмы, Architecture/ADR и проверки.
2. Решения владельца и expanded MVP перекрывают старые исключения AI и коммерческие потолки подключений, сохраняя исходные safety-контракты.
3. F07–F10 раскрывают уникальные алгоритмы capacity, диагностики, транспорта и fair runtime, которых нет в полном объёме в общих родителях.
4. contracts/f11-* содержат исходную схему входящего контекста и обязательные поправки A28 и C1v2; F12 — явно непринятый зависимый план, не свидетельство готовности.
5. CJM A задаёт визуальный маршрут; текущий расширенный scope определяет START-HERE и спецификации.

## Что исключено

- Нижние дубли F01–F06, полностью покрытые каноническими родителями и исходным планом AC.
- Старые validation/review/handoff/implementation отчёты, исследования доноров и генерации тулкита.
- Телеметрия, логи, screenshots, исходники и зависимости; исключение — четыре документа с уникальными F11/F12 контрактами, перенесённые в contracts/.
- Более ранние F12 A9/A17 и байтовый дубль A7v2 в пакете A8.
- docs/Completion.md: текущий статус уже приведён в START-HERE.md.
- docs/CJM_Variants.md и CJM B/C: выбор A и его обоснование уже приведены в START-HERE.md.

## Самостоятельные документы

| Путь | Почему оставлен |
|---|---|
| docs/PRD.md | Business problem, target users, product boundaries and weekly metric. |
| docs/Specification.md | Full original FR/GROWTH scope, safety-v1 thresholds and scenarios. |
| docs/Architecture.md | Base distributed-monolith, tenant/key/data boundaries; F08/F09 summaries do not incorporate their full contracts. |
| docs/ADR.md | Explicit approved credential-encryption and transaction/pool/payment decisions. |
| docs/Pseudocode.md | Full original algorithms, immutable submission boundary, semantic stop dedup, payment and attribution authority. |
| docs/Refinement.md | Original security/concurrency/mutation/browser failure obligations. |
| docs/decisions-owner.md | Owner scope/approval and model-routing authority. |
| docs/plans/mvp-xl-plan.md | Exact inherited AC-N7-001…012, not reproduced verbatim by expanded plan. |
| docs/plans/expanded-mvp-plan.md | Approved full F07–F15 scope, A1–A3 workload/retention/resource assumptions and SLO denominator. |
| docs/features/expanded-mvp/01_specification.md | Expanded FR/AC001…009 and story scope. |
| docs/features/expanded-mvp/02_pseudocode.md | Expanded admission/context/AI/reply/SLO algorithms and state contracts. |
| docs/features/expanded-mvp/03_architecture.md | Expanded storage and component boundaries, keeping existing authorities. |
| docs/features/expanded-mvp/04_refinement.md | Expanded edge matrix and mandatory AI content gate. |
| docs/features/expanded-mvp/05_completion.md | Exact expanded parent test titles and live rollback/monitoring requirements, distinct from actual acceptance. |
| docs/features/expanded-mvp/ai-policy-v1.md | Exact allowed FAQ/snippet policy, C01–C24 variants, deterministic assembly and separate actual-model gate. |
| docs/features/expanded-mvp/provider-capabilities.md | Provider interfaces, data-retention disclosure and unconfirmed external gate requirements. |
| docs/reuse-inventory.md | Compatible donors and rejected auth/crypto/queue transfers with rationale. |
| docs/test-scenarios.md | Concrete original BDD example rows beyond high-level FR text. |
| docs/tests/security-scenarios.md | 22 corrective security/stop/AEAD/auth/payment BDD cases. |
| docs/acceptance-traceability.md | Inherited acceptance mapping and historical source receipt pointers. |
| docs/cjm/cohort-desk.html | Chosen A standalone interactive CJM/layout guide, including simulated states. |
| docs/features/f07-connected-capacity/01_specification.md | F07 unique requirements and literal AC: 120s lease, atomic global30, quarantine release, keyset tenant pagination and billing regression. Parent summaries/references do not contain this complete contract. |
| docs/features/f07-connected-capacity/02_pseudocode.md | F07 unique data/state/algorithm contracts: 120s lease, atomic global30, quarantine release, keyset tenant pagination and billing regression. Parent summaries/references do not contain this complete contract. |
| docs/features/f07-connected-capacity/03_architecture.md | F07 unique transaction/physical ownership placement: 120s lease, atomic global30, quarantine release, keyset tenant pagination and billing regression. Parent summaries/references do not contain this complete contract. |
| docs/features/f07-connected-capacity/04_refinement.md | F07 unique failure/mutation/native witness obligations: 120s lease, atomic global30, quarantine release, keyset tenant pagination and billing regression. Parent summaries/references do not contain this complete contract. |
| docs/features/f08-live-diagnostics/01_specification.md | F08 unique requirements and literal AC: independent TLS/AUTH diagnostics, phase/parser limits, admission, revision/COMMIT cancellation and operator publication race. Parent summaries/references do not contain this complete contract. |
| docs/features/f08-live-diagnostics/02_pseudocode.md | F08 unique data/state/algorithm contracts: independent TLS/AUTH diagnostics, phase/parser limits, admission, revision/COMMIT cancellation and operator publication race. Parent summaries/references do not contain this complete contract. |
| docs/features/f08-live-diagnostics/03_architecture.md | F08 unique transaction/physical ownership placement: independent TLS/AUTH diagnostics, phase/parser limits, admission, revision/COMMIT cancellation and operator publication race. Parent summaries/references do not contain this complete contract. |
| docs/features/f08-live-diagnostics/04_refinement.md | F08 unique failure/mutation/native witness obligations: independent TLS/AUTH diagnostics, phase/parser limits, admission, revision/COMMIT cancellation and operator publication race. Parent summaries/references do not contain this complete contract. |
| docs/features/f09-live-transport/01_specification.md | F09 unique requirements and literal AC: native bounded DATA/UID coverage, typed ambiguity, authenticated operation ownership and exact-child closure. Parent summaries/references do not contain this complete contract. |
| docs/features/f09-live-transport/02_pseudocode.md | F09 unique data/state/algorithm contracts: native bounded DATA/UID coverage, typed ambiguity, authenticated operation ownership and exact-child closure. Parent summaries/references do not contain this complete contract. |
| docs/features/f09-live-transport/03_architecture.md | F09 unique transaction/physical ownership placement: native bounded DATA/UID coverage, typed ambiguity, authenticated operation ownership and exact-child closure. Parent summaries/references do not contain this complete contract. |
| docs/features/f09-live-transport/04_refinement.md | F09 unique failure/mutation/native witness obligations: native bounded DATA/UID coverage, typed ambiguity, authenticated operation ownership and exact-child closure. Parent summaries/references do not contain this complete contract. |
| docs/features/f10-durable-runtime/01_specification.md | F10 unique requirements and literal AC: durable service turns, task/physical resource bounds, no-success-sleep correction, and superseding F11 C1v2 scheduling. Parent summaries/references do not contain this complete contract. |
| docs/features/f10-durable-runtime/02_pseudocode.md | F10 unique data/state/algorithm contracts: durable service turns, task/physical resource bounds, no-success-sleep correction, and superseding F11 C1v2 scheduling. Parent summaries/references do not contain this complete contract. |
| docs/features/f10-durable-runtime/03_architecture.md | F10 unique transaction/physical ownership placement: durable service turns, task/physical resource bounds, no-success-sleep correction, and superseding F11 C1v2 scheduling. Parent summaries/references do not contain this complete contract. |
| docs/features/f10-durable-runtime/04_refinement.md | F10 unique failure/mutation/native witness obligations: durable service turns, task/physical resource bounds, no-success-sleep correction, and superseding F11 C1v2 scheduling. Parent summaries/references do not contain this complete contract. |
| docs/features/f08-live-diagnostics/capability-contracts.md | Exact selected native protocol/runtime constraints; parent library capability descriptions are not dependency choices. |
| docs/features/f08-live-diagnostics/scenarios.md | Derived scenario examples/negative conditions beyond parent-level acceptance statements. |
| docs/features/f09-live-transport/capability-contracts.md | Exact selected native protocol/runtime constraints; parent library capability descriptions are not dependency choices. |
| docs/features/f09-live-transport/scenarios.md | Derived scenario examples/negative conditions beyond parent-level acceptance statements. |
| contracts/f11-inbound-plan.md | Only substantive F11 inbound schema/MIME/store/AAD/retention implementation packet; unique clauses are not fully contained in expanded FR005. |
| contracts/f11-a28-corrections.md | Mandatory exact C1–C4 replacements validating the F11 draft, including semantic event mapping and frozen classifier. |
| contracts/f11-c1-capacity-window-v2.md | Unique quantitative/atomic-admission/queue/restart clauses beyond embedded F10 C1v2 summary. |
| contracts/f12-corrected-planning-candidate-v2.md | Latest corrected F12 planning candidate: complete useful bounded provider/budget/draft/approval plan with V01–V03 current-authority/HTTPS/retention corrections. |
