# N7 «Когорта»: начать здесь

Этот пакет — документы для генерации полного утверждённого N7, включая expanded MVP F07–F15. Исходник: ветка `feature/07-cold-email-warmup`, ревизия `7f6b848c1348aed0477493c31fac28f0d8f1b9d2`, проект `projects/07-cold-email-warmup`. Содержимое проекта сохранено по относительным путям; выбранные F11/F12 материалы имеют явные пути в `selection.json`. Здесь нет продуктового исходного кода или секретов. Донорские проекты, внешние ссылки и исторические evidence не означают, что их код включён.

Практическая задача: небольшой B2B-оператор подключает ящики, добровольно участвует в общем пуле и запускает согласованные цепочки. Нужны минимум два независимо согласившихся tenant; без пары показывается waiting. Прогрев, цепочки и AI используют общий дневной бюджет; ответ/отписка/жалоба прекращают ещё не отправленные шаги. Репутация неизвестна до проверяемых наблюдений; SMTP accepted не означает доставку или inbox placement.

## Задание для coding agent

«Используй этот пакет, чтобы создать N7 с полным утверждённым scope. Сначала составь карту FR/AC → алгоритм → архитектура → проверка и найди противоречия по указанному ниже приоритету. Реализуй исходные identity/tenant isolation, безопасное SMTP/IMAP подключение, раздельное consent, pooled warmup, персонализированные цепочки, stop-on-reply, unsubscribe/suppression/complaints, доказуемые наблюдения, TEST checkout и growth/partner attribution. Добавь unlimited connected, конечную активную ёмкость, настоящий ограниченный transport/runtime, bounded inbound context, OpenAI drafts/HITL, отдельную AI reply authority и честную full-path SLO отчётность. Используй CJM A как основу кабинета. Все live/provider/LLM/spend/deploy действия требуют отдельного применимого разрешения; наличие описания или credentials не даёт его. Не объявляй полную готовность по fixture-тестам или ещё непринятому кандидату».

## Порядок чтения

1. `docs/decisions-owner.md`, `docs/PRD.md`, `docs/plans/expanded-mvp-plan.md`: зачем продукт, полный scope и A1–A3.
2. `docs/Specification.md`, `docs/ADR.md`, `docs/Pseudocode.md`, `docs/Architecture.md`, `docs/Refinement.md`: исходные неизменяемые guards и полный первоначальный FR/GROWTH scope. `docs/plans/mvp-xl-plan.md` сохраняет точные AC-N7-001…012.
3. `docs/features/expanded-mvp/01_specification.md` → `02_pseudocode.md` → `03_architecture.md` → `04_refinement.md` → `05_completion.md`; затем `ai-policy-v1.md` и `provider-capabilities.md`.
4. Выбранные подробные F07–F10 роли, capability contracts и BDD. Краткая ссылка из родителя не заменяет содержимое дочернего контракта.
5. `contracts/f11-inbound-plan.md` и `contracts/f11-a28-corrections.md`; затем `contracts/f11-c1-capacity-window-v2.md` и F10 C1v2. Исполнять первоначальный F11 draft без поправок запрещено. `contracts/f12-corrected-planning-candidate-v2.md` — зависимый planning candidate: связывать с принятым F11 интерфейсом и проверять заново перед кодом.
6. `docs/test-scenarios.md`, `docs/tests/security-scenarios.md`, `docs/acceptance-traceability.md`, `docs/reuse-inventory.md`; сопоставить с текущими пробелами ниже.
7. Открыть `docs/cjm/cohort-desk.html`. Это выбранный A, самостоятельный интерактивный DEMO и ориентир интерфейса. Числа — иллюстрация, не измерение. Другие варианты B/C не включены; в экспортной копии удалены только footer-ссылки на B/C, историческое исключение AI отмечено как отменённое. Исходный CJM не менялся; точная трансформация и hashes фиксируются сборщиком.

## Приоритет и противоречия

OWN-N7-004/005 отменяют первоначальное исключение AI и старые коммерческие лимиты числа подключённых ящиков. Full scope включает F07–F15 и не отменяет исходные FR/GROWTH требования. Unlimited connected означает отсутствие коммерческого потолка записей; активная ёмкость конечна и атомарна: 30 глобально, 100 connected в контрольной нагрузке, ≥3 tenant, общий default10/day и ceiling30/day. Нижние provider limits имеют приоритет. Локальные TEST платежи сохраняются; CRM, покупка доменов и live paid billing не добавлены.

Исторические «no product LLM call», «AI excluded», local-only реализации и таблицы возможностей Nodemailer/ImapFlow не ограничивают утверждённый expanded scope и не выбирают зависимости. Принятые F08/F09 используют native Node TLS/SMTP/UID IMAP. Более поздние специальные F07–F10 contracts уточняют родительские алгоритмы; безопасность FIRST global lock(7,1), server AEAD+AАD, раздельные consent/authority, no-network-in-transaction и unknown delivery без blind retry сохраняется.

Для F11 A28 C1–C4 исправляют первоначальный план. Поздний A7v2/F10 C1v2 заменяет только scheduling C1: одна невозобновляемая 12s capture window, каждый из двух этапов ≤5s, максимум три body windows в существующих четырёх IMAP jobs, атомарное admission/first physical slot после complete proof, исходный FIFO/service order и absolute450s queue deadline с inherited expiry. Требуется ALL30 с двумя legal2800ms этапами ready≤240s и full300s evidence; фактический header complete gap≤30s/fair selection≤60s. Старый A5 вариант «оба этапа в общей5s window» — сохранённая история. Ни READY-план, ни корректная схема не подтверждают feasibility/приёмку.

AI policy v1 разрешает initial autopilot только для server-selected FAQ intents и точной сборки заранее утверждённых snippets. Свободный текст модели — HITL. Confidence не даёт authority. C01–C24 и variants:0 неразрешённых раскрытий/обязательств,100% корректных HOLD,≥11/12 полезных positive. Local fixture gate, отдельно разрешённый actual-model gate и live full-path pilot — разные проверки.

Arrival→SMTP accepted p95<300s измеряется при исходном eligible denominator; error/unknown/overdue имеют +infinity и не исчезают. Arrival требует проверяемого серверного источника; Date/observed_at и произвольный INTERNALDATE не подмена. HITL ожидание входит во время. F15 требует полного7day окна и отдельно разрешённых аккаунтов, peers, provider/OpenAI model/project/budget, content consent и operational gate.

OWN-N7-006 заменяет историческую модельную схему: profile `model-routing-econom`, planning/review — requested gpt-6.1-sol/high, coding — requested gpt-6.1-sol/medium; reviewer fresh. Requested модель не выдаётся за host-confirmed actual.

## Состояние на ревизии пакета

F01–F10 приняты локально в указанной source-bound композиции. Публичный кабинет — прежний F08 preview: это не подтверждение deployment F10/F11. Сейчас preview разрешает Gmail-host allowlist; известный HTTP400/сообщение интерфейса исправляется отдельно и не означает произвольную поддержку всех провайдеров.

F11 остаётся непринятым: обязательный ALL30 first-header witness показал32.54–45.736s при допустимых30s. F12–F14 не завершены; F15 live7day gate открыт не был. Исторические PASS в acceptance/completion относятся только к своим точным revisions/components; F06 documentary/delivery gaps не стираются последующим fixture-pass. Пакет не переносит историческое разрешение preview на новые deployment или внешние вызовы.

`HIERARCHY.md` объясняет выбор и исключения; `MANIFEST.json` даёт исходные пути, SHA256 и приоритеты документов. Исторические review/receipt/frozen-copy ссылки могут указывать на исключённые материалы: это provenance, не обязательные отсутствующие нормативные документы. Нормативные F11 поправки включены непосредственно. Восстановление полной истории, донорского кода и текущих внешних capabilities — отдельная работа, если она понадобится.

## Выбранный CJM

Выбран A — Cohort Desk: основной пользователь сам подключает ящики, отдельно разрешает общий прогрев и запускает цепочки. Основной цикл роста — сетевой эффект: новые добровольные пригодные участники расширяют выбор независимых собеседников. Партнёрская атрибуция поддерживает этот сценарий; она не заменяет его реферальным или ручным агентским sales-процессом. Aha наступает только при датированном, сопоставимом и подтверждённом улучшении наблюдения репутации; до этого честный статус unknown. Число участников и демонстрационные числа улучшение не доказывают.
