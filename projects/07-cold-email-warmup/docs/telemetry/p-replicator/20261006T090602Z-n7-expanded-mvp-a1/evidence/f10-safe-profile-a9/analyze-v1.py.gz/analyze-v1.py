from pathlib import Path
import json,statistics,collections,datetime,hashlib
base=Path('/tmp/n7-f10-safe-profile-a9');d=json.loads((base/'profile-v1.json').read_text())
def stats(values):
 values=sorted(values);return {'n':len(values),'median':statistics.median(values) if values else None,'p95':values[min(len(values)-1,int(len(values)*.95))] if values else None,'max':max(values) if values else None,'sum':sum(values)}
children=[p for p in d['processes'] if p['parent']];timings=collections.defaultdict(list)
for row in (d.get('drained') or {}).get('timings',[]):timings[row['label']].append(row['elapsedMs'])
waits=collections.Counter();wall=(d['ended']-d['begun'])/1000
for sample in d['dbWaits']:
 for row in sample['states']:waits[str(row['state'])+':'+str(row['wait_event_type'])+':'+str(row['wait_event'])]+=int(row['count'])
peer=[r['elapsedMs'] for r in d['peerLatencies']];startup=[r['firstTransportAt']-r['startedAt'] for r in children if r['firstTransportAt'] is not None];lifetime=[r['exitObservedAt']-r['startedAt'] for r in children if r['exitObservedAt'] is not None];gaps=[v for row in d['gaps'] for v in row['gaps']]
rootStat=(d.get('drained') or {}).get('stat');cpuFinal=sum(map(int,rootStat.split(') ')[1].split()[11:15])) if rootStat else None
summary={'source':d['source'],'begun':d['begun'],'ended':d['ended'],'cpus':d['cpus'],'wallSeconds':wall,'failure':d['failure'],'participants':len(d['gaps']),'completionsMin':min(len(r['completed']) for r in d['gaps']),'gaps':stats(gaps),'mailboxesOver30':sum(any(v>30000 for v in r['gaps']) for r in d['gaps']),'processCount':len(children),'startupToFirstTCPMs':stats(startup),'childLifetimeMs':stats(lifetime),'peerTLSMs':stats(peer),'cpuTicksFinalWithReapedChildren':cpuFinal,'cpuPercentOneCore':cpuFinal/d['hz']/wall*100 if cpuFinal is not None else None,'rssKbPeak':max(r['rssKb'] for r in d['resources']),'fdPeak':max(r['fds'] for r in d['resources']),'processPeak':max(r['processCount'] for r in d['resources']),'physicalConnectionsPeak':max(r['physicalConnections'] for r in d['resources']),'runtimeAndDBTimingsMs':{k:stats(v) for k,v in timings.items()},'PGWaitStateWeightedSamples':dict(waits),'operationCounts':d['operationCounts'],'guard':(d.get('drained') or {}).get('guard'),'drain':{'outcome':d['outcome'],'drained':bool(d.get('drained')),'elapsedMs':d['drainMs']},'samplingLimitations':d['sampling'],'telemetryTruncated':(d.get('drained') or {}).get('telemetryTruncated')}
(base/'summary-v1.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
