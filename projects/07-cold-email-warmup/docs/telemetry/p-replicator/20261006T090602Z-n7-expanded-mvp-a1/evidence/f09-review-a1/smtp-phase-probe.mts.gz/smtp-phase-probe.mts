import { TLSSocket } from 'node:tls';
import { writeFileSync } from 'node:fs';
import { transportFixture, transportInput, transportAllowlist } from '/tmp/n7-f09-review-20261006/projects/07-cold-email-warmup/tests/f09-transport-fixture.ts';
import { submitSmtp } from '/tmp/n7-f09-review-20261006/projects/07-cold-email-warmup/src/dispatch/smtp.ts';
import { renderLiveMessage } from '/tmp/n7-f09-review-20261006/projects/07-cold-email-warmup/src/dispatch/message.ts';
const original=TLSSocket.prototype.write;
let phaseStart=0;
TLSSocket.prototype.write=function(chunk:any,...args:any[]){
 if(chunk==='250-fixture\r\n250 AUTH PLAIN\r\n'){
  phaseStart=Date.now();
  setTimeout(()=>original.call(this,'250-fixture\r\n'),6000);
  setTimeout(()=>original.call(this,'250 AUTH PLAIN\r\n'),12000);
  return true;
 }
 return original.call(this,chunk,...args);
} as any;
const fixture=await transportFixture();
try {
 const result=await submitSmtp(transportInput,renderLiveMessage('a@example.com','b@example.com',{subject:'phase probe',body:'probe'},'https://example.com').message,transportAllowlist,new AbortController().signal,fixture.connector);
 const evidence={source:'35039ad32e933d7a4d0bf0f7621f7722e5774ef6',result:result.kind,ehloElapsedMs:Date.now()-phaseStart,commands:fixture.verbs,expected:'EHLO phase must time out at 10000 ms before AUTH/DATA',node:process.version};
 writeFileSync('/tmp/n7-f09-review-a1/smtp-phase-result.json',JSON.stringify(evidence,null,2));
 console.log(JSON.stringify(evidence));
}finally{TLSSocket.prototype.write=original;await fixture.close();}
