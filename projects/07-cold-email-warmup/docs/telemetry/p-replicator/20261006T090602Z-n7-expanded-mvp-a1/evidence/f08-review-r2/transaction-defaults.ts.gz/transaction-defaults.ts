import assert from 'node:assert/strict';
import { eligibilityTransaction } from '/tmp/n7-f08-review-20261006/projects/07-cold-email-warmup/src/consent/transaction.ts';
async function main(){
 for(const mode of ['default','guard','reject'] as const){
  const trace:string[]=[];const pool:any={connect:async()=>({query:async(s:string)=>{trace.push(s);},release(){trace.push('release');}})};
  const work=async()=>{trace.push('operation');return 42;};
  const guard=mode==='default'?undefined:()=>{trace.push('guard');if(mode==='reject')throw new Error('cancelled');};
  if(mode==='reject')await assert.rejects(eligibilityTransaction(pool,work,guard),/cancelled/);else assert.equal(await eligibilityTransaction(pool,work,guard),42);
  assert.deepEqual(trace,['BEGIN','SELECT pg_advisory_xact_lock(7,1)','operation',...(mode==='default'?[]:['guard']),mode==='reject'?'ROLLBACK':'COMMIT','release']);
 }
 console.log(JSON.stringify({source:'521ae2b3208c7ffa2f33a6701c84a816f07c3d5a',test:'actual common helper FIRST lock optional synchronous guard defaults rollback release',cases:3,result:'pass',limitation:'deterministic Pool seam; full real PG146 evidence supplied separately'}));
}
main().catch(e=>{console.error(e.message);process.exitCode=1;});
