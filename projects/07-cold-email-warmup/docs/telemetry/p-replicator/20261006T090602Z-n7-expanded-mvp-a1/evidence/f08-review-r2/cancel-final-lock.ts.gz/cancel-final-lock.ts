import assert from 'node:assert/strict';
import { randomBytes, randomUUID } from 'node:crypto';
import { DiagnosticStore } from '/tmp/n7-f08-review-20261006/projects/07-cold-email-warmup/src/mailboxes/diagnostic-store.ts';
import { encryptCredentials } from '/tmp/n7-f08-review-20261006/projects/07-cold-email-warmup/src/mailboxes/crypto.ts';
import { configFingerprint } from '/tmp/n7-f08-review-20261006/projects/07-cold-email-warmup/src/mailboxes/diagnostic-authority.ts';
async function main(){
 const tenant=randomUUID(),id=randomUUID(),allowlist=new Map([['smtp.example.com',30],['imap.example.com',30]]);
 const input={label:'fixture',senderAddress:'a@example.com',smtpHost:'smtp.example.com',smtpPort:465,imapHost:'imap.example.com',imapPort:993,smtpUsername:'fixture',smtpPassword:'fixture',imapUsername:'fixture',imapPassword:'fixture',dailyLimit:10};
 const ring={activeVersion:'v1',keys:new Map([['v1',randomBytes(32)]])};
 const row:any={state:'configured',metadata:input,credential_envelope:encryptCredentials(input,tenant,id,ring),diagnostic_revision:'0',diagnostic_attempt:null};
 const fingerprint=configFingerprint(allowlist);
 const grant={authority_revision:'1',state:'active',expires_at:new Date(Date.now()+60000),scope:{scope:'diagnostics',tenant,mailbox:id,...input,configFingerprint:fingerprint},config_fingerprint:fingerprint};
 let locks=0,published=false,committedAfterAbort=false;
 let reached!:()=>void,release!:()=>void;const waiting=new Promise<void>(r=>{reached=r});const gate=new Promise<void>(r=>{release=r});const controller=new AbortController();
 const query=async(sql:string,args:any[]=[])=>{
  if(sql.includes('pg_advisory_xact_lock')){locks++;if(locks===2){reached();await gate;}return {rows:[]};}
  if(sql==='COMMIT'){if(published&&controller.signal.aborted)committedAfterAbort=true;return {rows:[]};}
  if(sql==='BEGIN'||sql==='ROLLBACK')return {rows:[]};
  if(sql.includes('FROM diagnostic_authority'))return {rows:[grant]};
  if(sql.includes('clock_timestamp'))return {rows:[{now:new Date()}]};
  if(sql.startsWith('SELECT id FROM mailbox'))return {rows:[{id}],rowCount:1};
  if(sql.startsWith('SELECT ')&&sql.includes('FROM mailbox'))return {rows:[{...row}]};
  if(sql.includes('diagnostic_revision=diagnostic_revision+1')){row.diagnostic_revision='1';row.diagnostic_attempt=args[2];return {rows:[{diagnostic_revision:'1'}]};}
  if(sql.includes('SET diagnostic_result=$3')){published=true;row.diagnostic_result=args[2];return {rows:[]};}
  if(sql.includes('SET diagnostic_attempt=NULL')){row.diagnostic_attempt=null;return {rows:[]};}
  throw new Error('unexpected query');
 };
 const pool:any={query,connect:async()=>({query,release(){}})};
 const factory:any=(budget:any)=>{let lines:string[]=[];return {budget,async open(_h:string,p:number){lines=p===465?['220 fixture','250 AUTH PLAIN','235 accepted']:['* OK fixture','* CAPABILITY AUTH=PLAIN','a1 OK done','+ ','a2 OK accepted'];},async upgrade(){},async line(){return lines.shift()!;},write(){},close(){}};};
 const store=new DiagnosticStore(pool,ring,allowlist,factory,'protocol_fixture');
 const pending=store.run(tenant,id,controller.signal);await waiting;controller.abort();release();await assert.rejects(pending,/diagnostic_cancelled/);
 assert.equal(published,false);assert.equal(committedAfterAbort,false);assert.equal(row.diagnostic_attempt,null);
 console.log(JSON.stringify({source:'521ae2b3208c7ffa2f33a6701c84a816f07c3d5a',test:'actual DiagnosticStore abort while final FIRST-lock waiter',result:'pass',published,committedAfterAbort,attemptCleared:row.diagnostic_attempt===null,limitation:'deterministic Pool/Channel seams; not a real PostgreSQL or HTTP witness'}));
}
main().catch(e=>{console.error(e.message);process.exitCode=1;});
