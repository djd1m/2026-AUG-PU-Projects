const fs=require('node:fs');
const vm=require('node:vm');
const assert=require('node:assert/strict');
const ts=require('/tmp/n7-f08-dependency-fix-20261006/projects/07-cold-email-warmup/node_modules/typescript');
async function main(){
 const source=fs.readFileSync('/tmp/n7-f08-review-20261006/projects/07-cold-email-warmup/src/mailboxes/diagnostic-operator.ts','utf8');
 const code=ts.transpileModule(source,{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ESNext}}).outputText;
 let invoked=false,stdout='',stderr='';
 const processFixture={argv:['node','diagnostic-operator.js','revoke','0'],stdout:{write:s=>{stdout+=s}},stderr:{write:s=>{stderr+=s}},exitCode:undefined};
 const context=vm.createContext({process:processFixture,Buffer,Date,Error});
 const dependencies={
 'node:fs/promises':{open:async()=>{throw new Error('unexpected file access')}},
 '../config.js':{loadConfig:()=>({databaseUrl:'fixture',operatorTokenDigest:null})},
 '../db.js':{createPool:()=>({end:async()=>{}}),ready:async()=>true},
 './diagnostic-authority.js':{parseGrant:x=>x,publishAuthority:async()=>{invoked=true;return '1'}}
 };
 const module=new vm.SourceTextModule(code,{context});
 await module.link(async name=>{const exports=dependencies[name];assert.ok(exports);return new vm.SyntheticModule(Object.keys(exports),function(){for(const [k,v]of Object.entries(exports))this.setExport(k,v)},{context});});
 await module.evaluate();assert.equal(invoked,false);assert.match(stderr,/authority_action_failed/);assert.equal(stdout,'');assert.equal(processFixture.exitCode,1);
 console.log(JSON.stringify({source:'521ae2b3208c7ffa2f33a6701c84a816f07c3d5a',test:'actual diagnostic-operator control flow with null configured capability',operatorTokenDigest:null,publishAuthorityInvoked:invoked,successfulRevisionReceipt:false,limitation:'transpiled unmodified entrypoint with isolated config/database module seams; no real DB mutation'}));
}
main().catch(e=>{console.error(e.message);process.exitCode=1;});
